namespace CSC202Assign1._1
{
    public partial class CSC202Assign1_1 : Form
    {
        public CSC202Assign1_1()
        {
            InitializeComponent();
        }

        private void BTAdd_Click(object sender, EventArgs e)
        {
            // variables to hold the values of the textboxes
            string sNum1 = TB1stNumb.Text;
            string sNum2 = TB2ndNumb.Text;

            // variables to hold the converted values of the textboxes
            double dNum1 = 0;
            double dNum2 = 0;

            // check if the values entered in TB1stNumb are valid numbers and if not display an error message
            if (!double.TryParse(sNum1, out dNum1))
            {
                LBResults.Text = "Please enter a valid number!!";
            }
            // check if the values entered in TB2ndNumb are valid numbers and if not display an error message
            else if (!double.TryParse(sNum2, out dNum2))
            {
                LBResults.Text = "Please enter a valid number!!";
            }
            // if both values are valid numbers then add them together and display the result!
            else
            {
                // variable to hold the result of the addition
                double dResult = dNum1 + dNum2;
                // display the result in the LBResults label
                LBResults.Text = dResult.ToString();
            }


        }

        private void BTMinus_Click(object sender, EventArgs e)
        {
            // variables to hold the values of the textboxes 
            string sNum1 = TB1stNumb.Text;
            string sNum2 = TB2ndNumb.Text;

            // variables to hold the converted values of the textboxes
            double dNum1 = 0;
            double dNum2 = 0;

            // check if the values entered in TB1stNumb are valid numbers and if not display an error message
            if (!double.TryParse(sNum1, out dNum1))
            {
                LBResults.Text = "Please enter a valid number!!";
            }
            // check if the values entered in TB2ndNumb are valid numbers and if not display an error message
            else if (!double.TryParse(sNum2, out dNum2))
            {
                LBResults.Text = "Please enter a valid number!!";
            }
            // if both values are valid numbers then subtract them and display the result!
            else
            {
                // variable to hold the result of the subtraction
                double dResult = dNum1 - dNum2;
                // display the result in the LBResults label
                LBResults.Text = dResult.ToString();
            }
        }

        private void BTMult_Click(object sender, EventArgs e)
        {
            // variables to hold the values of the textboxes
            string sNum1 = TB1stNumb.Text;
            string sNum2 = TB2ndNumb.Text;

            // variables to hold the converted values of the textboxes
            double dNum1 = 0;
            double dNum2 = 0;

            // check if the values entered in TB1stNumb are valid numbers and if not display an error message
            if (!double.TryParse(sNum1, out dNum1))
            {
                LBResults.Text = "Please enter a valid number!!";
            }
            // check if the values entered in TB2ndNumb are valid numbers and if not display an error message
            else if (!double.TryParse(sNum2, out dNum2))
            {
                LBResults.Text = "Please enter a valid number!!";
            }
            // if both values are valid numbers then multiply them and display the result!
            else
            {
                // variable to hold the result of the multiplication
                double dResult = dNum1 * dNum2;
                // display the result in the LBResults label
                LBResults.Text = dResult.ToString();
            }
        }

        private void BTDiv_Click(object sender, EventArgs e)
        {
            // variables to hold the values of the textboxes
            string sNum1 = TB1stNumb.Text;
            string sNum2 = TB2ndNumb.Text;

            // variables to hold the converted values of the textboxes
            double dNum1 = 0;
            double dNum2 = 0;

            // check if the values entered in TB1stNumb are valid numbers and if not display an error message
            if (!double.TryParse(sNum1, out dNum1))
            {
                LBResults.Text = "Please enter a valid number!!";
            }
            // check if the values entered in TB2ndNumb are valid numbers and if not display an error message
            else if (!double.TryParse(sNum2, out dNum2))
            {
                LBResults.Text = "Please enter a valid number!!";
            }
            // if both values are valid numbers then divide them and display the result!
            else
            {
                // variable to hold the result of the division
                double dResult = dNum1 / dNum2;
                // display the result in the LBResults label
                LBResults.Text = dResult.ToString();
            }

        }
    }
}
