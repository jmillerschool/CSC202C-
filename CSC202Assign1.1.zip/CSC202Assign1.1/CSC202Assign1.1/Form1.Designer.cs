﻿namespace CSC202Assign1._1
{
    partial class CSC202Assign1_1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            LB1stNumb = new Label();
            LB2ndNumb = new Label();
            LBResults = new Label();
            TB1stNumb = new TextBox();
            TB2ndNumb = new TextBox();
            BTAdd = new Button();
            BTMinus = new Button();
            BTMult = new Button();
            BTDiv = new Button();
            SuspendLayout();
            // 
            // LB1stNumb
            // 
            LB1stNumb.AutoSize = true;
            LB1stNumb.Font = new Font("Yu Gothic", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            LB1stNumb.Location = new Point(35, 74);
            LB1stNumb.Margin = new Padding(5, 0, 5, 0);
            LB1stNumb.Name = "LB1stNumb";
            LB1stNumb.Size = new Size(247, 27);
            LB1stNumb.TabIndex = 0;
            LB1stNumb.Text = "Please enter a number:";
            // 
            // LB2ndNumb
            // 
            LB2ndNumb.AutoSize = true;
            LB2ndNumb.Font = new Font("Yu Gothic", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            LB2ndNumb.Location = new Point(367, 74);
            LB2ndNumb.Name = "LB2ndNumb";
            LB2ndNumb.Size = new Size(313, 27);
            LB2ndNumb.TabIndex = 1;
            LB2ndNumb.Text = "Please enter another number:";
            // 
            // LBResults
            // 
            LBResults.AutoSize = true;
            LBResults.Font = new Font("Yu Gothic", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            LBResults.Location = new Point(230, 350);
            LBResults.Name = "LBResults";
            LBResults.Size = new Size(94, 27);
            LBResults.TabIndex = 2;
            LBResults.Text = "Results:";
            // 
            // TB1stNumb
            // 
            TB1stNumb.Location = new Point(80, 127);
            TB1stNumb.Name = "TB1stNumb";
            TB1stNumb.Size = new Size(159, 38);
            TB1stNumb.TabIndex = 3;
            // 
            // TB2ndNumb
            // 
            TB2ndNumb.Location = new Point(453, 127);
            TB2ndNumb.Name = "TB2ndNumb";
            TB2ndNumb.Size = new Size(159, 38);
            TB2ndNumb.TabIndex = 4;
            // 
            // BTAdd
            // 
            BTAdd.Font = new Font("Yu Gothic", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            BTAdd.Location = new Point(80, 226);
            BTAdd.Name = "BTAdd";
            BTAdd.Size = new Size(58, 54);
            BTAdd.TabIndex = 5;
            BTAdd.Text = "+";
            BTAdd.UseVisualStyleBackColor = true;
            BTAdd.Click += BTAdd_Click;
            // 
            // BTMinus
            // 
            BTMinus.Font = new Font("Yu Gothic", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            BTMinus.Location = new Point(239, 228);
            BTMinus.Name = "BTMinus";
            BTMinus.Size = new Size(58, 52);
            BTMinus.TabIndex = 6;
            BTMinus.Text = "-";
            BTMinus.UseVisualStyleBackColor = true;
            BTMinus.Click += BTMinus_Click;
            // 
            // BTMult
            // 
            BTMult.Font = new Font("Yu Gothic", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            BTMult.Location = new Point(398, 226);
            BTMult.Name = "BTMult";
            BTMult.Size = new Size(57, 50);
            BTMult.TabIndex = 7;
            BTMult.Text = "*";
            BTMult.TextAlign = ContentAlignment.BottomCenter;
            BTMult.UseVisualStyleBackColor = true;
            BTMult.Click += BTMult_Click;
            // 
            // BTDiv
            // 
            BTDiv.Font = new Font("Yu Gothic", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            BTDiv.Location = new Point(554, 224);
            BTDiv.Name = "BTDiv";
            BTDiv.Size = new Size(58, 52);
            BTDiv.TabIndex = 8;
            BTDiv.Text = "/";
            BTDiv.UseVisualStyleBackColor = true;
            BTDiv.Click += BTDiv_Click;
            // 
            // CSC202Assign1_1
            // 
            AutoScaleDimensions = new SizeF(12F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.CornflowerBlue;
            ClientSize = new Size(711, 452);
            Controls.Add(BTDiv);
            Controls.Add(BTMult);
            Controls.Add(BTMinus);
            Controls.Add(BTAdd);
            Controls.Add(TB2ndNumb);
            Controls.Add(TB1stNumb);
            Controls.Add(LBResults);
            Controls.Add(LB2ndNumb);
            Controls.Add(LB1stNumb);
            Font = new Font("Yu Gothic", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Margin = new Padding(5);
            Name = "CSC202Assign1_1";
            Text = "CSC202Assign1_1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label LB1stNumb;
        private Label LB2ndNumb;
        private Label LBResults;
        private TextBox TB1stNumb;
        private TextBox TB2ndNumb;
        private Button BTAdd;
        private Button BTMinus;
        private Button BTMult;
        private Button BTDiv;
    }
}
