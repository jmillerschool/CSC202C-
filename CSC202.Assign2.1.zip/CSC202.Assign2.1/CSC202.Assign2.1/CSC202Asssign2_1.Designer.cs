﻿namespace CSC202.Assign2._1
{
    partial class CSC202Asssign2_1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblWelcome = new Label();
            lblInstructions = new Label();
            txtGuess = new TextBox();
            lblOutput = new Label();
            btnGuess = new Button();
            btnRules = new Button();
            lblRules = new Label();
            SuspendLayout();
            // 
            // lblWelcome
            // 
            lblWelcome.AutoSize = true;
            lblWelcome.BackColor = Color.White;
            lblWelcome.Font = new Font("Yu Gothic", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblWelcome.Location = new Point(160, 37);
            lblWelcome.Name = "lblWelcome";
            lblWelcome.Size = new Size(465, 31);
            lblWelcome.TabIndex = 0;
            lblWelcome.Text = "Welcome to my amazing guessing game! \r\n";
            lblWelcome.Click += lblWelcome_Click;
            // 
            // lblInstructions
            // 
            lblInstructions.AutoSize = true;
            lblInstructions.BackColor = Color.White;
            lblInstructions.Font = new Font("Yu Gothic", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblInstructions.Location = new Point(186, 68);
            lblInstructions.Name = "lblInstructions";
            lblInstructions.Size = new Size(414, 31);
            lblInstructions.TabIndex = 1;
            lblInstructions.Text = "Please press the button to see rules.";
            lblInstructions.Click += lblInstructions_Click;
            // 
            // txtGuess
            // 
            txtGuess.Font = new Font("Yu Gothic", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtGuess.Location = new Point(186, 287);
            txtGuess.Name = "txtGuess";
            txtGuess.Size = new Size(156, 46);
            txtGuess.TabIndex = 2;
            // 
            // lblOutput
            // 
            lblOutput.AutoSize = true;
            lblOutput.BackColor = Color.White;
            lblOutput.Font = new Font("Yu Gothic", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblOutput.Location = new Point(134, 375);
            lblOutput.Name = "lblOutput";
            lblOutput.Size = new Size(32, 31);
            lblOutput.TabIndex = 3;
            lblOutput.Text = "...";
            // 
            // btnGuess
            // 
            btnGuess.BackColor = Color.Thistle;
            btnGuess.Font = new Font("Yu Gothic", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnGuess.Location = new Point(361, 287);
            btnGuess.Name = "btnGuess";
            btnGuess.Size = new Size(264, 46);
            btnGuess.TabIndex = 4;
            btnGuess.Text = "Make your guess";
            btnGuess.UseVisualStyleBackColor = false;
            btnGuess.Click += btnGuess_Click;
            // 
            // btnRules
            // 
            btnRules.BackColor = Color.Thistle;
            btnRules.Font = new Font("Yu Gothic", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnRules.Location = new Point(306, 130);
            btnRules.Name = "btnRules";
            btnRules.Size = new Size(156, 36);
            btnRules.TabIndex = 5;
            btnRules.Text = "Rules";
            btnRules.UseVisualStyleBackColor = false;
            btnRules.Click += btnRules_Click;
            // 
            // lblRules
            // 
            lblRules.AutoSize = true;
            lblRules.BackColor = Color.White;
            lblRules.Font = new Font("Yu Gothic", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblRules.Location = new Point(160, 200);
            lblRules.Name = "lblRules";
            lblRules.Size = new Size(32, 31);
            lblRules.TabIndex = 6;
            lblRules.Text = "...";
            // 
            // CSC202Asssign2_1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.CadetBlue;
            ClientSize = new Size(800, 450);
            Controls.Add(lblRules);
            Controls.Add(btnRules);
            Controls.Add(btnGuess);
            Controls.Add(lblOutput);
            Controls.Add(txtGuess);
            Controls.Add(lblInstructions);
            Controls.Add(lblWelcome);
            Name = "CSC202Asssign2_1";
            Text = "Assign2.1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblWelcome;
        private Label lblInstructions;
        private TextBox txtGuess;
        private Label lblOutput;
        private Button btnGuess;
        private Button btnRules;
        private Label lblRules;
    }
}
