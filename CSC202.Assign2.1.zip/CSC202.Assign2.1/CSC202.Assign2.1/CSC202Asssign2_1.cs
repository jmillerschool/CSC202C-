namespace CSC202.Assign2._1
{
    public partial class CSC202Asssign2_1 : Form
    {
        // create my variables to store the target number
        private int iTargetNumber;

        public CSC202Asssign2_1()
        {
            InitializeComponent();

            // generate a random number between 1 and 100 and store it in the variable
            iTargetNumber = generateRandomNumber(1, 101);
        }

        // create a function to generate a random number and return it withing the range
        private int generateRandomNumber(int iMin, int iMax)
        {
            //create a variable to store the random number
            int iRandomNumber = 0;

            // create a new instance of the Random class
            Random rnd = new Random();

            // generate a random number between the min and max values
            iRandomNumber = rnd.Next(iMin, iMax);

            // return the random number to the calling function 
            return iRandomNumber;
        }

        // create a function to tell the player if they are too high or too low or if they have won
        private string checkGuess()
        {
            string strInput = txtGuess.Text;
            string strMessage = " ";

            // Check if the input is a number by using the TryParse method in taking the string strInput and converting it to an integer.
            if (int.TryParse(strInput, out int iUserGuess))
            {
                // Check if the user's guess is equal to the target number and display the appropriate message
                if (iUserGuess == iTargetNumber)
                {
                    strMessage = "Congratulations! You guessed the correct number!";
                }
                else if (iUserGuess < iTargetNumber)
                {
                    strMessage = "The number is higher than " + iUserGuess.ToString() + ". Please guess again!";
                }
                else
                {
                    strMessage = "The number is lower than " + iUserGuess.ToString() + ".  Please guess again!";
                }
            }
            // If the input is not a number, display an error message
            else
            {
                strMessage = "Please enter a valid number.";
            }
            // Display the message in the lblOutput label on the formx 
            lblOutput.Text = strMessage;

            return strMessage;
        }
        // create a void function to display the rules of the game
        private void displayRules()
        {
            // create a string variable to store the rules of the game
            string strRules = "Please guess a number between 1 and 100.";


            // display the rules in the lblOutput label on the form
            lblRules.Text = strRules;
        }

        private void btnGuess_Click(object sender, EventArgs e)
        {
            // call the checkGuess function to check the user's guess
            checkGuess();

        }

        private void lblWelcome_Click(object sender, EventArgs e)
        {

        }

        private void lblInstructions_Click(object sender, EventArgs e)
        {

        }

        private void btnRules_Click(object sender, EventArgs e)
        {

            // if statement to change the message if button is clicked again
            if (lblRules.Text == "Please guess a number between 1 and 100.")
            {
                lblRules.Text = "You already know the rules! Just guess a number!";
            }
            else
            {
                // set the lblRules label to display the rules of the game
                displayRules();
            }
        }
    }
}
